//
//  ViewController.h
//  FlickrApiTest
//
//  Created by DebutMac3 on 14/09/14.
//  Copyright (c) 2014 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController <UICollectionViewDataSource, UICollectionViewDelegate,CLLocationManagerDelegate>
{
    NSMutableArray  *photoTitles;         // Titles of images
    NSMutableArray  *photoSmallImageData; // Image data (thumbnail)
    NSMutableArray  *photoURLsLargeImage; // URL to larger image

    BOOL check;
    
    IBOutlet UICollectionView *imageCollectionView;
}

//Flag string
@property (nonatomic, retain) NSString *searchStr;

//CLLocationManager and CLLocation instance
@property (strong, nonatomic) CLLocationManager *locationManager;
@property (strong, nonatomic) CLLocation *location;

@end
