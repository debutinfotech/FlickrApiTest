//
//  ViewController.m
//  FlickrApiTest
//
//  Created by DebutMac3 on 14/09/14.
//  Copyright (c) 2014 ___FULLUSERNAME___. All rights reserved.
//

#import "ViewController.h"
#import "JSON.h"
#import "UIImageView+WebCache.h"
#import "MyCell.h"
#import "JKPopup.h"
#import "JKProgressHUD.h"
#import "Helper.h"

#define debug(format, ...) CFShow([NSString stringWithFormat:format, ## __VA_ARGS__]);

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Private interface definitions
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
@interface ViewController()
@property(nonatomic, strong) JKPopup *popup;            //Loader Pop Up

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data;
- (void)searchFlickrPhotos:(NSString *)text;
@end

//#error
// Replace with your Flickr key
NSString *const FlickrAPIKey = @"8229a70e31bba7a1d7e495980122a4cc";

@implementation ViewController
@synthesize popup = _popup;

#pragma mark - hidePopup methods
- (void) hidePopup:(id)sender
{
	[self.popup hide];
}

//+++++++++++++++++++++++++++++ViewController Life Cycle Method +++++++++++++++++++++++
#pragma mark - ViewController Life Cycle Method
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    [imageCollectionView registerNib:[UINib nibWithNibName:@"MyCell" bundle:nil] forCellWithReuseIdentifier:@"MyCell"];

}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
    self.navigationController.navigationBarHidden = TRUE;
    
    self.locationManager = [[CLLocationManager alloc]init];
    self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    self.locationManager.delegate = self;
    [self.locationManager startUpdatingLocation];

    // Initialize our arrays
    photoTitles = [[NSMutableArray alloc] init];
    photoSmallImageData = [[NSMutableArray alloc] init];
    photoURLsLargeImage = [[NSMutableArray alloc] init];
    
    self.searchStr = @"placeid";
    check = TRUE;
}

//+++++++++++++++++++++++++++++locationManager Delegate methods++++++++++++++++++++++++++
#pragma mark - locationManager Delegate methods
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    // Store incoming data into a string
	NSString *jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    // Create a dictionary from the JSON string
	NSDictionary *results = [jsonString JSONValue];
    NSLog(@"%@", results);
    
    if ([self.searchStr isEqualToString:@"placeid"])
    {
        NSLog(@"%@", [[[[results valueForKey:@"places"] valueForKey:@"place"] objectAtIndex:0] valueForKey:@"place_id"]);
        [self searchFlickrPhotos:[[[[results valueForKey:@"places"] valueForKey:@"place"] objectAtIndex:0] valueForKey:@"place_id"]];
        
    }
    else
    {
        // Build an array from the dictionary for easy access to each entry
        NSArray *photos = [[results objectForKey:@"photos"] objectForKey:@"photo"];
        
        // Loop through each entry in the dictionary...
        for (NSDictionary *photo in photos)
        {
            // Get title of the image
            NSString *title = [photo objectForKey:@"title"];
            
            // Save the title to the photo titles array
            [photoTitles addObject:(title.length > 0 ? title : @"Untitled")];
            
            // Build the URL to where the image is stored (see the Flickr API)
            // In the format http://farmX.static.flickr.com/server/id/secret
            // Notice the "_s" which requests a "small" image 75 x 75 pixels
            NSString *photoURLString = [NSString stringWithFormat:@"https://farm%@.static.flickr.com/%@/%@_%@_s.jpg", [photo objectForKey:@"farm"], [photo objectForKey:@"server"], [photo objectForKey:@"id"], [photo objectForKey:@"secret"]];
            
            NSLog(@"photoURLString: %@", photoURLString);
            //debug(@"photoURLString: %@", photoURLString);
            
            // The performance (scrolling) of the table will be much better if we
            // build an array of the image data here, and then add this data as
            // the cell.image value (see cellForRowAtIndexPath:)
            [photoSmallImageData addObject:[NSData dataWithContentsOfURL:[NSURL URLWithString:photoURLString]]];
            
            // Build and save the URL to the large image so we can zoom
            // in on the image if requested
            photoURLString = [NSString stringWithFormat:@"https://farm%@.static.flickr.com/%@/%@_%@_m.jpg", [photo objectForKey:@"farm"], [photo objectForKey:@"server"], [photo objectForKey:@"id"], [photo objectForKey:@"secret"]];
            [photoURLsLargeImage addObject:[NSURL URLWithString:photoURLString]];
            
            //debug(@"photoURLsLareImage: %@\n\n", photoURLString);
            NSLog(@"photoURLsLareImage: %@\n\n", photoURLString);

        }
        
        [imageCollectionView reloadData];
        
        [self.popup hide];

    }
}

//Method ask for sharing device's current location
- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation
{
    [self.locationManager stopUpdatingLocation];
    
    NSLog(@"Latitude is :%@", [NSString stringWithFormat:@"%f", newLocation.coordinate.latitude]);
    NSLog(@"Latitude is :%@", [NSString stringWithFormat:@"%f", newLocation.coordinate.longitude]);
    
    if (check)
    {
        if ([Helper isConnectedToInternet])
        {
            self.popup = [[JKProgressHUD alloc] initWithFrame:CGRectMake(0, 0, 70, 70)];
            
            [self.popup showAnimated:YES];
            
            
            check = FALSE;
            [self searchPlace_IdByLatLong:[NSString stringWithFormat:@"%f", newLocation.coordinate.latitude] andLong:[NSString stringWithFormat:@"%f", newLocation.coordinate.longitude]];
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No Internet" message:@"Please check your internet connection." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            
            [alert show];
        }

    }
    
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    [self.locationManager stopUpdatingLocation];
}


//+++++++++++++++++++++++++++++ Search Place_Id by lat and long ++++++++++++++++++++++++++
- (void) searchPlace_IdByLatLong : (NSString *) lat andLong : (NSString *)lang
{
    NSString *urlString = [NSString stringWithFormat:@"https://api.flickr.com/services/rest/?method=flickr.places.findByLatLon&api_key=%@&lat=%@&lon=%@&accuracy=3&format=json&nojsoncallback=1", FlickrAPIKey, lat, lang];
    //&per_page=50
    
    // Create NSURL string from formatted string
	NSURL *url = [NSURL URLWithString:urlString];
    
    // Setup and start async download
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL: url];
    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    
}

//+++++++++++++++++++++++++++++ Search images by place_id of flickr api ++++++++++++++++++++++
-(void)searchFlickrPhotos:(NSString *)text
{
    self.searchStr = @"placeidphotos";
    
    // Build the string to call the Flickr API
	NSString *urlString = [NSString stringWithFormat:@"https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=%@&place_id=%@&per_page=50&format=json&nojsoncallback=1", FlickrAPIKey, text];
    
    // Create NSURL string from formatted string
	NSURL *url = [NSURL URLWithString:urlString];
    
    // Setup and start async download
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL: url];
    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    
}


#pragma mark - UICollectionView DataSource

-(NSInteger)numberOfSectionsInCollectionView:
(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSLog(@"%d", (int)photoURLsLargeImage.count);
    return photoURLsLargeImage.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (MyCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    MyCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MyCell" forIndexPath:indexPath];
    
    NSString *url = [NSString stringWithFormat:@"%@", [photoURLsLargeImage objectAtIndex:indexPath.row]];
    NSLog(@"'%@'", url);
    
    [cell.cellImage.layer setBorderColor: [[UIColor colorWithRed:212.0/255.0 green:212.0/255.0 blue:212.0/255.0 alpha:1.0] CGColor]];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        [cell.cellImage.layer setBorderWidth: 3.0];

        
    }
    else
    {
        [cell.cellImage.layer setBorderWidth: 6.0];

    }
    
    [cell.cellImage setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage imageNamed:@"loading.jpg"]];

    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    //Add code for item select handler
}



//+++++++++++++++++++++++++++++ Memmory management Method ++++++++++++++++++++++++++++++++
#pragma mark - Memmory management Method
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

@end
